<?php
declare(strict_types=1);

/**
 * ISP lookup preko ip-api.com sa jednostavnim file-cache.
 * Poziv: api.php?ip=8.8.8.8
 */

header('Content-Type: application/json; charset=UTF-8');

$backupFile = __DIR__ . DIRECTORY_SEPARATOR . 'apibackup.txt';
$errorFile  = __DIR__ . DIRECTORY_SEPARATOR . 'errors.txt';

/**
 * Jednostavno logovanje grešaka u fajl.
 */
function log_error(string $errorFile, string $message): void
{
    file_put_contents($errorFile, $message . PHP_EOL, FILE_APPEND | LOCK_EX);
}

/**
 * Pokuša naći IP u cache-u (tačno po liniji).
 * Format cache linije: "IP = {json}"
 */
function cache_get(string $backupFile, string $ip): ?string
{
    if (!is_file($backupFile)) {
        return null;
    }

    $needle = $ip . ' = ';

    $fh = fopen($backupFile, 'rb');
    if (!$fh) {
        return null;
    }

    while (($line = fgets($fh)) !== false) {
        // Trim samo newline, da ostane JSON netaknut
        $line = rtrim($line, "\r\n");

        if (str_starts_with($line, $needle)) {
            fclose($fh);
            return substr($line, strlen($needle)); // vraća samo JSON dio
        }
    }

    fclose($fh);
    return null;
}

/**
 * Upisuje IP->JSON u cache.
 */
function cache_put(string $backupFile, string $ip, string $json): void
{
    $line = $ip . ' = ' . $json;
    file_put_contents($backupFile, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}

/**
 * Sigurno uzimanje URL sadržaja sa timeout-om.
 */
function http_get(string $url, int $timeoutSeconds = 5): string|false
{
    $ctx = stream_context_create([
        'http' => [
            'timeout' => $timeoutSeconds,
            'header'  => "User-Agent: isp-lookup/1.0\r\n",
        ],
    ]);

    return @file_get_contents($url, false, $ctx);
}

/* ------------------------- Ulaz ------------------------- */

$inputIp = $_GET['ip'] ?? '';

if (!filter_var($inputIp, FILTER_VALIDATE_IP)) {
    log_error($errorFile, 'Invalid IP address!!! ' . $inputIp);
    echo json_encode(['status' => 0, 'error' => 'Invalid IP address!!!'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ------------------------- Cache ------------------------- */

$cached = cache_get($backupFile, $inputIp);
if ($cached !== null && $cached !== '') {
    // U cache-u je već spremljen JSON, vraćamo ga “kako jeste”
    echo $cached;
    exit;
}

/* ------------------------- Remote lookup ------------------------- */

// ip-api JSON endpoint + fields maska (kao u tvom originalu). [web:115]
$url = 'http://ip-api.com/json/' . rawurlencode($inputIp) . '?fields=531';

$jData = http_get($url, 6);
if ($jData === false || $jData === '') {
    log_error($errorFile, "Remote request failed for IP: {$inputIp}");
    echo json_encode(['status' => 0, 'error' => 'Remote lookup failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

$rData = json_decode($jData);
if (!is_object($rData)) {
    log_error($errorFile, "Invalid JSON response for IP: {$inputIp}");
    echo json_encode(['status' => 0, 'error' => 'Invalid response'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Provjera polja (tvoj original je gledao samo strlen($rData->isp))
$isp = $rData->isp ?? '';
if (!is_string($isp) || $isp === '') {
    log_error($errorFile, 'there is no ISP at the address ' . $inputIp);
    echo json_encode(['status' => 0, 'error' => 'there is no ISP at the address'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ------------------------- Output + cache ------------------------- */

$out = [
    'status'   => 1,
    'isp_info' => [
        'description'  => (string)($rData->isp ?? ''),
        'city'         => (string)($rData->city ?? ''),
        'country_code' => (string)($rData->countryCode ?? ''),
        'country_name' => (string)($rData->country ?? ''),
    ],
];

$jsonOut = json_encode($out, JSON_UNESCAPED_UNICODE);
if ($jsonOut === false) {
    log_error($errorFile, "JSON encode failed for IP: {$inputIp}");
    echo '{"status":0,"error":"Internal error"}';
    exit;
}

echo $jsonOut;
cache_put($backupFile, $inputIp, $jsonOut);
