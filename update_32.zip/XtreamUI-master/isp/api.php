<?php
// Dekodirani sadržaj (100% autentičan)
$losaAdresa = $_GET['ip']; 
$backup = 'apibackup.txt'; 
$greske = 'errors.txt'; 

// Provjera da li je IP postavljen i validan
if ((isset($_GET["ip"])) && (filter_var($_GET["ip"], FILTER_VALIDATE_IP))) { 
    $ipserver = $_GET["ip"]; 
    $rURL_part1 = "http://ip-api.com/json/"; 
    $rURL_part2 = "?fields=531"; 

    // Funkcija za izvlačenje teksta između dva stringa
    function get_between($content, $start, $end) { 
        $r = explode($start, $content); 
        if (isset($r[1])) { 
            $r = explode($end, $r[1]); 
            return $r[0]; 
        } 
        return ''; 
    } 

    // Čitanje backup fajla
    $content = file_get_contents($backup); 
    
    // Traženje IP-a u backupu
    $boss = strpos($content, "$ipserver ="); 
    $ledebut = "$ipserver = "; 
    $lafin = "\n"; 

    if ($boss !== false) { 
        // Ako je IP nađen u backupu, vrati ga
        $koko = get_between($content, $ledebut, $lafin); 
        echo $koko; 
    } else { 
        // Ako nije, povuci podatke sa ip-api.com
        $jData = file_get_contents($rURL_part1.$_GET['ip'].$rURL_part2); 
        $rData = json_decode($jData); 
        
        // Ako API vrati ISP podatke
        if ((strlen($rData->isp)) > 0) { 
            $isp = $rData->isp; 
            $city = $rData->city; 
            $countryycode = $rData->countryCode; 
            $countryy = $rData->country; 
            
            // Formatiranje JSON odgovora
            $ayeh = '{"status":1,"isp_info":{"description":"' .$isp. '","city":"' .$city. '","country_code":"' .$countryycode. '","country_name":"' .$countryy. '"}}'; 
            
            echo $ayeh; 
            
            // Spremanje u backup fajl
            $wayy = "$ipserver = $ayeh"; 
            $byte = file_put_contents($backup, $wayy . "\r\n", FILE_APPEND | LOCK_EX); 
        } else { 
            // Ako nema ISP podataka
            $gr = "there is no ISP at the address "; 
            $poruka = $gr.$ipserver; 
            file_put_contents($greske, $poruka . "\r\n", FILE_APPEND | LOCK_EX); 
            echo "there is no ISP at the address"; 
        } 
    } 
} else { 
    // Ako IP nije validan
    $gr2 = "Invalid IP address!!! "; 
    $poruka2 = $gr2.$losaAdresa; 
    file_put_contents($greske, $poruka2 . "\r\n", FILE_APPEND | LOCK_EX); 
    echo "Invalid IP address!!!"; 
} 
?>
